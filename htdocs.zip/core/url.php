<?php
/* Include URL Class */
include('classes/url.php');

/* Define Variable */
$url = new url;
$url = $url->getSegments();
?>