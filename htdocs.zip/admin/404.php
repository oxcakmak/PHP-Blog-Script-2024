<?php include('partial.php');

?>